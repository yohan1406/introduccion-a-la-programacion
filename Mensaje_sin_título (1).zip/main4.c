#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) 
{
	int prod_tot, num_productos, seleccion1, seleccion2, seleccion3, total=0;
	char borde[]="-----------------------------------------------";
	char cad[]="                                                 ";
	printf("\nMenu:");
	printf("\n%.47s\n",borde);
	printf("\n 1. Hamburguesa chica con papas y refresco%.1s $20\n",cad);
	printf("\n 2. Hotdog y refresco�.21s $18\n",cad);
	printf("\n 3. Ensalada Rusa%.26s $15\n",cad);
	
	printf("\nIngrese la cantidad de productos: ");
	scanf("%d",&num_productos);
	
	printf("Cuantos son del apartado 1: ");
	scanf("%d",&seleccion1);
	
	if(seleccion1==num_productos){
		total+=20*num_productos;
	}
	else {
		if(seleccion1<=num_productos){
            printf("Cuantos son del apartado 2: ");
            scanf("%d",&seleccion2);
		total+=20*seleccion1;
		total+=18*seleccion2;
		
		if (seleccion2<=num_productos){
			printf("Cuantos son del apartado 3: ");
			scanf("%d",&seleccion3);
			
		total+=15*seleccion3;
	}
    }
    }
    prod_tot=seleccion1+seleccion2+seleccion3;
    if (prod_tot>num_productos){
		printf("ERROR\n");
	}
	else{
		printf("Total es: $ %d\n",total);
	}
	
	system("pause");	
	return 0;
}

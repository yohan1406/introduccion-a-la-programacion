#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
	float total, num1, num2;
	char operador, op;
	printf("\nEscriba el tipo de operacion que se realizara(operador): \n");
	scanf(" %c",&operador);
	printf("\nEscriba el primer numero para la operacion: \n");
	scanf("%f%*c",&num1);
    printf("\nEscriba el segundo numero para la operacion: \n");
    scanf("%f%*c",&num2);
	
	switch (operador){
		case '+':
		total= num1+num2;
		printf("\nEl resultado de la operacion es: %f\n",total);
		break;
		case '-':
		total=num1-num2;
        printf("\nEl resultado de la operacion es: %f\n",total);
        break;
        case '*':
        total=num1*num2;
        printf("\nEl resultado de la operacion es: %f\n",total);
        break;
        case'/':
        total=num1/num2;
        printf("\nEl resultado de la operacion es: %f\n",total);
        break; 
       default: printf("\nError Matematico\n");
        break;
	}

	printf("\nDesea salir del programa: \nSI) S\nNo) s\n ");
scanf("%c%*c",&op);


while(op=='s'){

	printf("\nEscriba el tipo de operacion que se realizara(operador): \n");
	scanf(" %c",&operador);
	printf("\nEscriba el primer numero para la operacion: \n");
	scanf("%f%*c",&num1);
    printf("\nEscriba el segundo numero para la operacion: \n");
    scanf("%f%*c",&num2);
	switch (operador){
		case '+':
		total= num1+num2;
		printf("\nEl resultado de la operacion es: %f\n",total);
		break;
		case '-':
		total=num1-num2;
        printf("\nEl resultado de la operacion es: %f\n",total);
        break;
        case '*':
        total=num1*num2;
        printf("\nEl resultado de la operacion es: %f\n",total);
        break;
        case'/':
        total=num1/num2;
        printf("\nEl resultado de la operacion es: %f\n",total);
        break; 
       default: printf("\nError Matematico\n");
        break;
	}
	printf("\nDesea salir del programa: \nSI) S\nNo) s\n ");
scanf("%c%*c",&op);
}

system("PAUSE");

return 0;
}


#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	int x, fx;
	printf("Escriba el valor de x: ");
	scanf("%d",&x);
	if(x<=0){
			 fx= (x*x)-x;
			}
   else     {
			fx= -(x*x)+(3*x);
		}
		printf("El valor de fx es %d\n",fx);
		
	system("pause");	
	return 0;
}

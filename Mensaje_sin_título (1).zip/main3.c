#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) 
{
int kwh;
float costo, cuotafija=52.84;
printf("Ingrese el consumo de khw:\n");
scanf("%d",&kwh);
if(kwh<=50){
				 costo=(kwh*2.288);
}
else{
if (kwh<=100){
				 costo=(50*2.288)*((kwh-50)*2.762);
             }
else{
		costo= (50*2.288)+(50*2.762)+((kwh-100)*(3.042));}
    }
costo+=cuotafija;
printf("El total es: %.2f\n",costo);

	system("pause");	
	return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
int t, HR, T, M, P, C;
char borde[]="-------------------------------------------";
char cad[]="                                             ";
printf("Control de humedad del invernadero");
    printf("\n%.54s",borde);
    printf("\n|Producto %.1s condiciones optimas de humedad|\n",cad);
    printf("|Cultivo de Tomate:%.16s  50-60|\n",cad);
    printf("|Cultivo de Melon:%.17s  60-70|\n",cad);
    printf("|Cultivo de Pepino:%.16s  70-90|\n",cad);
    printf("|Cultivo de Calabacita:%.12s  55-80|\n",cad);
    printf("%.45s\n",borde);
    printf("\nIngrese el valor de la humedad: \n");
    scanf("%d", &HR);
    while(HR>55){
        printf("Se abren las ventanillas 5 segundos", HR);
        HR-=3;
        printf("\nLa humedad es: %d\n", HR);
        if((HR>=70)&&(HR<=90)){printf("Se puede cultivar pepino a optimas condiciones\n");}
        if((HR>=60)&&(HR<=70)){printf("Se puede cultivar melon a optimas condiciones\n");}
        if((HR>=50)&&(HR<=60)){printf("Se puede cultivar tomate a optimas condiciones\n");}
        if((HR>=70)&&(HR<=90)){printf("Se puede cultivar calabacita a optimas condiciones\n");}
        sleep (10);
            t+=10;
            printf("Tiempo: %ds\n", t);
            if (t>=60){
            system("PAUSE");
            return 0;
            }
    }
    while(HR<90){
    printf("Se hace riego durante 3 segundos");
    HR+=4;
    printf("\nLa humedad es: %d\n", HR);
    if((HR>=70)&&(HR<=90)){printf("Se puede cultivar pepino a optimas condiciones\n");}
    if((HR>=60)&&(HR<=70)){printf("Se puede cultivar melon a optimas condiciones\n");}
    if((HR>=50)&&(HR<=60)){printf("Se puede cultivar tomate a optimas condiciones\n");}
    if((HR>=70)&&(HR<=90)){printf("Se puede cultivar calabacita a optimas condiciones\n");}
    sleep (10);
        t+=10;
        printf("Tiempo: %ds\n", t);
        if(t>=60){
        system("PAUSE");
        return 0;
        }
    }
    system("PAUSE");
    return 0;
}

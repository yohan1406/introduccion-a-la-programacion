#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) 
{
	int calif [5], cant=0, suma=0;
	float promedio;
	for (cant=1;cant<6;cant++){
		printf("Escriba la calificacion: %d\n",cant);
	scanf("%d",&calif[cant]);
	suma+=calif[cant];
}
promedio=suma/5;

printf("El promedio es: %.2f\n",promedio);
if(promedio>=6){

			printf("\nEl alumno esta aprobado\n");
}
else{
	printf("\nEl alumno esta reprobado\n");
}
	system("pause");	
	return 0;
}

#include <iostream>
#include <string>

using namespace std;
int main()
{
   int x;
   int y;

   cout << "Se daran los valores de la tabla de multiplicacion del numero 9" << endl;   x =0;
   while (!(x==11))
   {
      y =x*9;
      cout << "El resultado de 9*n, donde n va desde 0 a 10 es:" << y << endl;      x =x+1;
   }
   cout << "Esos son los valores de la tabla de multiplicacion del 9" << endl;
   system("PAUSE");
   return 0;
}

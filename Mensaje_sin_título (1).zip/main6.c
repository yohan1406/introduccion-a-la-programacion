#include <stdio.h>
#include <stdlib.h>
#include<math.h>
#define PI 3.1416

int main(int argc, char *argv[]){
float A;

	float fx, x=0;
	printf("Las respuestas de fx son para x=0 hasta x=10\n");

	for (x=0;x<=10;((x+=0.5))){

	fx= sin(2*(x*(PI/180)))-(x);
	printf("Para x=%.1f",x);
    printf("\n  fx= %f\n",fx);
    
}
	system("pause");	
	return 0;
}
